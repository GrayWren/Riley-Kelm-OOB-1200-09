package Assignment4;
import java.util.Scanner;

public class Throw  {
private int pins=10;
private boolean isStrike;
private boolean isSpare;

    public int pinGet() {
        return pins;
    }

    public void pinSet(int x) {
        this.pins = x;

    }

    public boolean isStrikeGet() {
        return isStrike;
    }

    public void isStrikeSet(boolean x) {
        this.isStrike = x;
    }

    public boolean isSpareGet() {
        return isSpare;
    }

    public void isSpareSet(boolean x) {
        this.isSpare = x;
    }

    public static void main(String[] args) {

    }











}


